#include "$safeitemname$.h"
#include "XEngine.h"
#include "GameObject.h" 
#include "Component.h"
using namespace XEngine;

// Register to be created and serialized.
REGISTER_COMPONENT($safeitemname$, "$safeitemname$")

$safeitemname$::$safeitemname$() {}
$safeitemname$::~$safeitemname$() {}

// Start is called on the objects first update.
void $safeitemname$::Start()
{

}

// Update is called once per frame.
void $safeitemname$::Update()
{

}

// Draw the inspector for your custom component.
void $safeitemname$::DrawInspector()
{

}

